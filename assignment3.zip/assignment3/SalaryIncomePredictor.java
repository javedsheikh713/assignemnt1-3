package assignment3;

public class SalaryIncomePredictor {
	
	private String year;
	private String salary;
	private String frquency;
	private String percentage;
	private String amount;
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getFrquency() {
		return frquency;
	}
	public void setFrquency(String frquency) {
		this.frquency = frquency;
	}
	
	
	
}
